<!-- <div class="footer container-fluid bg-dark text-light">
    <p class="text-center py-2 mb-0">Copyright © 2021 Designed by <a href="https://github.com/darshankparmar" target="_blank" rel="noopener noreferrer">@darshankparmar</a></p>
</div> -->


<!-- //============================================================================ -->
<!-- <div class="py-2 border border-lighter border-bottom-0 border-left-0 border-right-0 bg-dark">
        <div class="container">
            <div class="row justify-content-between align-items-center text-center">
                <div class="col-md-3 text-md-left mb-3 mb-md-0">
                    <img src="pigga/assets/imgs/navbar-brand.svg" width="100" alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Pigga Landing page" class="mb-0">
                </div>
                <div class="col-md-9 text-md-right">
                    
                    <a href="home.php" class="px-3"><small class="font-weight-bold" style="color:white">PIZZA'S WORLD</small></a>
                    <a href="#" class="px-3"><small class="font-weight-bold" style="color:white">OUR LOCATION:INDIA</small></a>
                    <a href="#" class="px-3"><small class="font-weight-bold" style="color:white">HELP CENTER:0011 2323 4323</small></a>
                    <a href="#" class="pl-3"><small class="font-weight-bold" style="color:white">pizzaworld@gmail.com</small></a>
                </div>
            </div>
        </div>
    </div> -->



<!-- Footer Section Begin -->
<footer class="footer container-fluid bg-dark text-light">
    <div class="container" style="padding:20px">
        <div class="row">
            <div class="col-lg-2 col-md-3 col-sm-6">
                <div class="footer__widget">
                    <img src="pigga/assets/imgs/navbar-brand.svg" width="100" height="70"
                        alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, Pigga Landing page"
                        class="mb-2">
                    <ul>
                        <li><a href="home.php" style="color:white">Home</a></li>
                        <li><a href="index.php" style="color:white">Menu</a></li>
                        <li><a href="index.php" style="color:white">Categories</a></li>
                        <li><a href="viewOrder.php" style="color:white">Order</a></li>
                        <li><a href="about.php" style="color:white">About Us</a></li>
                        <li><a href="contact.php" style="color:white">Contact Us</a></li>
                        <li><a href="feedback.php" style="color:white">Feedback</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="footer__address" style="padding:30px">
                    <h4>Contact Us</h4><br>
                    <ul>
                        <li><i class="flaticon-placeholder-3"></i> Plot No 166, opp. diamond Institude, B/h someshwara
                            Bungalows ,vesu Surat-5</li>
                        <li><i class="fa fa-phone"></i> 704-336-5488</li>
                        <li><i class="fa fa-envelope"></i>ckpcmc@gmail.com </li>
                    </ul>
                </div>
            </div>
            <div class="mapouter"><div class="gmap_canvas">
                <iframe width="820" height="560" id="gmap_canvas" src="https://maps.google.com/maps?q=c.k.+pithawalla+&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                    <a href="https://www.alarm-clock.net/">online alarm clock</a><br>
                    <a href="https://www.time-date.net"></a><br>
                    <style>.mapouter{position: relative;text-align: right;height: 100px;width: 100px;}</style>
                    <a href="https://www.embedmaps.co">google map for my website</a>
                    <style>.gmap_canvas{overflow: hidden;background: none !important;height: 300px;width: 700px;}</style>
                </div>
            </div>
        </div>
    </div>
    <div class="footer__copyright">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="footer__copyright__text">
                        <p>PIZZA'S WORLD | Develop<i> for <a href="https://ckpcmc.org/"
                                    target="_blank" style="color:red"><b>C.K. Pithawalla college</b></a></p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</footer>
<!-- Footer Section End -->