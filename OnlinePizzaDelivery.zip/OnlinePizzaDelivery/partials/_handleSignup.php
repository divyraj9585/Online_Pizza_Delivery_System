<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
$showAlert = false;
$showError = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    include '_dbconnect.php';

    $username  = trim($_POST["username"]);
    $firstName = trim($_POST["firstName"]);
    $lastName  = trim($_POST["lastName"]);
    $email     = trim($_POST["email"]);
    $phone     = trim($_POST["phone"]);
    $password  = $_POST["password"];
    $cpassword = $_POST["cpassword"];

    // ----------------------------
    // VALIDATIONS
    // ----------------------------

    // No spaces allowed
    if (strpos($username, ' ') !== false || strpos($firstName, ' ') !== false || strpos($lastName, ' ') !== false) {
        $_SESSION['signup_error'] = "Spaces are not allowed in Username, First Name, or Last Name.";
        header("Location: /OnlinePizzaDelivery/index.php");
        exit();
    }

    // Only alphabets for names
    if (!preg_match("/^[A-Za-z]+$/", $firstName) || !preg_match("/^[A-Za-z]+$/", $lastName)) {
        $_SESSION['signup_error'] = "First Name and Last Name must contain only alphabets.";
        header("Location: /OnlinePizzaDelivery/index.php");
        exit();
    }

    // Email validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['signup_error'] = "Invalid email format.";
        header("Location: /OnlinePizzaDelivery/index.php");
        exit();
    }

    // Phone number validation
    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        $_SESSION['signup_error'] = "Phone number must be exactly 10 digits.";
        header("Location: /OnlinePizzaDelivery/index.php");
        exit();
    }

    // Password validation
    if (!preg_match("/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,10}$/", $password)) {
        $_SESSION['signup_error'] = "Password must be 6–10 characters long and contain at least one uppercase letter, one digit, and one special character.";
        header("Location: /OnlinePizzaDelivery/index.php");
        exit();
    }

    // ----------------------------
    // CHECK DUPLICATES
    // ----------------------------

    // Username already exists?
    $existSql = "SELECT * FROM `users` WHERE username = '$username'";
    $result = mysqli_query($conn, $existSql);

    if (mysqli_num_rows($result) > 0) {
        $_SESSION['signup_error'] = "Username already exists.";
        header("Location: /OnlinePizzaDelivery/index.php");
        exit();
    }

    // Phone already exists?
    $existPhoneSql = "SELECT * FROM `users` WHERE phone = '$phone'";
    $phoneResult = mysqli_query($conn, $existPhoneSql);

    if (mysqli_num_rows($phoneResult) > 0) {
        $_SESSION['signup_error'] = "Phone number already exists.";
        header("Location: /OnlinePizzaDelivery/index.php");
        exit();
    }

    // Email already exists? (optional but recommended)
    $existEmailSql = "SELECT * FROM `users` WHERE email = '$email'";
    $emailResult = mysqli_query($conn, $existEmailSql);

    if (mysqli_num_rows($emailResult) > 0) {
        $_SESSION['signup_error'] = "Email already exists.";
        header("Location: /OnlinePizzaDelivery/index.php");
        exit();
    }

    // ----------------------------
    // PASSWORD MATCH
    // ----------------------------

    if ($password !== $cpassword) {
        $_SESSION['signup_error'] = "Passwords do not match.";
        header("Location: /OnlinePizzaDelivery/index.php");
        exit();
    }

    // ----------------------------
    // INSERT INTO DATABASE
    // ----------------------------
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, firstName, lastName, email, phone, password, joinDate) 
            VALUES ('$username', '$firstName', '$lastName', '$email', '$phone', '$hash', current_timestamp())";

    if (mysqli_query($conn, $sql)) {
        $_SESSION['signup_success'] = "Account created successfully! You can now log in.";
        header("Location: /OnlinePizzaDelivery/index.php");
        exit();
    } else {
        die("Error inserting data: " . mysqli_error($conn));
    }
}
?>
