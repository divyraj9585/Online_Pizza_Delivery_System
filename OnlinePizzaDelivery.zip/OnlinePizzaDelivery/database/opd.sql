-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 05, 2026 at 06:38 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `opd`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(21) NOT NULL,
  `adminName` varchar(21) NOT NULL,
  `profilePic` varchar(255) DEFAULT NULL,
  `email` varchar(35) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `joinDate` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `adminName`, `profilePic`, `email`, `phone`, `password`, `joinDate`, `status`) VALUES
(7, 'admin', NULL, 'admin123@gmail.com', 9867687890, '$2y$10$0Qmx2o4tqclYE2XEYuiY2OSyabcEVZ3Z9i9b6krmkeOeNs0nk9dli', '2026-01-05 20:19:04', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `categorieId` int(12) NOT NULL,
  `categorieName` varchar(255) NOT NULL,
  `categorieImage` varchar(255) DEFAULT NULL,
  `categorieDesc` text NOT NULL,
  `categorieCreateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categorieId`, `categorieName`, `categorieImage`, `categorieDesc`, `categorieCreateDate`, `status`) VALUES
(22, 'VEG ITEMS', 'img/card-22.jpg', 'A delight for veggie lovers! ', '2025-03-22 18:34:49', 'active'),
(23, 'NON-VEG ITEM', 'img/card-23.jpg', 'Choose your favourite non-veg pizzas from the  Pizza world menu. Get fresh non-veg pizza with your choice of crusts & topping', '2025-03-22 18:36:21', 'active'),
(26, 'BEVERAGES', 'img/card-26.jpg', 'Complement your pizza with wide range of beverages available at Pizza World India', '2025-03-22 18:37:24', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contactId` int(21) NOT NULL,
  `userId` int(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `phoneNo` bigint(21) NOT NULL,
  `orderId` int(21) NOT NULL DEFAULT 0 COMMENT 'If problem is not related to the order then order id = 0',
  `message` text NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('new','resolved') NOT NULL DEFAULT 'new'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contactId`, `userId`, `email`, `phoneNo`, `orderId`, `message`, `time`, `status`) VALUES
(6, 6, 'poojazanzmera31@gmail.com', 9879719578, 17, 'Where My Order Reached???', '2025-03-25 20:01:04', 'resolved'),
(7, 6, 'poojazanzmera31@gmail.com', 9879719578, 25, 'where is my order', '2025-03-30 10:47:17', 'resolved'),
(8, 6, 'poojazanzmera31@gmail.com', 9879719578, 0, 'hgfcfc', '2025-04-01 09:20:49', 'resolved');

-- --------------------------------------------------------

--
-- Table structure for table `contactreply`
--

CREATE TABLE `contactreply` (
  `id` int(21) NOT NULL,
  `contactId` int(21) NOT NULL,
  `userId` int(21) NOT NULL,
  `message` text NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contactreply`
--

INSERT INTO `contactreply` (`id`, `contactId`, `userId`, `message`, `datetime`) VALUES
(1, 6, 6, 'Comming Soon...', '2025-03-25 20:01:29'),
(2, 7, 6, 'comes', '2025-03-30 10:50:30'),
(3, 8, 6, 'OKTFTYYG', '2025-04-01 09:21:45');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_boys`
--

CREATE TABLE `delivery_boys` (
  `id` int(11) NOT NULL,
  `delivery_boy_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `vehicle_type` varchar(3) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `delivery_boys`
--

INSERT INTO `delivery_boys` (`id`, `delivery_boy_name`, `first_name`, `last_name`, `email`, `phone`, `password`, `vehicle_type`, `status`, `created_at`) VALUES
(4, 'ujas', 'Ujas', 'zanzmera', 'ujaszanzmera06@gmail.com', '9638619578', '$2y$10$LykoX879fHBegKwIDJOZ2ufbpPz5xtMQvNenwzpNGELrBdXJLe3Au', 'no', 'rejected', '2025-03-22 17:19:45'),
(5, 'mohan', 'Mohan', 'Patel', 'Mohan@gmail.com', '7653433252', '$2y$10$VcJ.Z69MUAZZW1m9qrbqLOKdUJeBieaT3fBmPU14jSjqVI4tymXFy', 'yes', 'approved', '2025-03-25 15:05:10'),
(6, 'Raj', 'Raj', 'Nayak', 'rajnayak21@gmail.com', '9765365264', '$2y$10$aOEqAr4C4NzzLgjX8DDlZerIRCvnvqZOFM4bSfnxh6g8VLI5xlDeO', 'no', 'pending', '2025-03-25 15:06:03');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` enum('1','2','3','4','5') NOT NULL COMMENT '1 = Worst, 5 = Best',
  `comment` text NOT NULL,
  `submission_date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `user_id`, `rating`, `comment`, `submission_date`, `status`) VALUES
(2, 6, '4', 'nice services', '2025-03-23 11:28:15', 'pending'),
(4, 16, '5', 'Good Services and food is amazing......', '2025-04-10 17:45:05', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `itemId` int(12) NOT NULL,
  `itemName` varchar(255) NOT NULL,
  `itemImage` varchar(255) DEFAULT NULL,
  `itemPrice` int(12) NOT NULL,
  `itemDesc` text NOT NULL,
  `itemCategorieId` int(12) NOT NULL,
  `itemPubDate` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('available','unavailable') NOT NULL DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`itemId`, `itemName`, `itemImage`, `itemPrice`, `itemDesc`, `itemCategorieId`, `itemPubDate`, `status`) VALUES
(69, 'Margherita', 'img/pizza-69.jpg', 99, 'A hugely popular margherita, with a deliciously tangy single cheese topping', 22, '2023-03-21 22:43:44', 'available'),
(70, 'Double Cheese Margherita', 'img/pizza-70.jpg', 150, 'The ever-popular Margherita - loaded with extra cheese... oodies of it', 22, '2023-03-21 22:48:52', 'available'),
(71, 'Farm House', 'img/pizza-71.jpg', 149, 'A pizza that goes ballistic on veggies! Check out this mouth watering overload of crunchy, crisp capsicum, succulent mushrooms and fresh tomatoes', 22, '2023-03-21 22:49:38', 'available'),
(72, 'Peppy Paneer', 'img/pizza-72.jpg', 190, 'Chunky paneer with crisp capsicum and spicy red pepper - quite a mouthful!', 22, '2023-03-21 22:50:17', 'available'),
(73, 'Mexican Green Wave', 'img/pizza-73.jpg\r\n', 149, 'A pizza loaded with crunchy onions, crisp capsicum, juicy tomatoes and jalapeno with a liberal sprinkling of exotic Mexican herbs.\r\n', 22, '2023-03-21 22:50:51', 'available'),
(74, 'Deluxe Veggie', 'img/pizza-74.jpg\r\n', 240, 'For a vegetarian looking for a BIG treat that goes easy on the spices, this one got it all..', 22, '2023-03-21 22:53:07', 'available'),
(75, 'Cheese N Corn', 'img/pizza-75.jpg\r\n', 199, 'Cheese I Golden Corn', 22, '2023-03-21 23:21:28', 'available'),
(76, 'PANEER MAKHANI', 'img/pizza-76.jpg\r\n', 199, ' Paneer and Capsicum on Makhani Sauce', 22, '2023-03-21 23:22:13', 'available'),
(77, 'Indi Tandoori Paneer', 'img/pizza-77.jpg\r\n', 240, 'It is hot. It is spicy. It is oh-so-Indian. Tandoori paneer with capsicum I red paprika I mint mayo\r\n', 22, '2023-03-21 23:23:00', 'available'),
(78, 'PEPPER BARBECUE CHICKEN', 'img/pizza-78.jpg\r\n', 199, 'Pepper Barbecue Chicken I Cheese', 23, '2023-03-21 23:50:46', 'available'),
(79, 'CHICKEN SAUSAGE', 'img/pizza-79.jpg\r\n', 249, 'Chicken Sausage I Cheese', 23, '2023-03-21 23:54:06', 'available'),
(80, 'Chicken Golden Delight', 'img/pizza-80.jpg\r\n', 249, 'Mmm! Barbeque chicken with a topping of golden corn loaded with extra cheese. Worth its weight in gold!', 23, '2023-03-21 23:56:35', 'available'),
(81, 'Chicken Dominator', 'img/pizza-81.jpg\r\n', 160, 'Treat your taste buds with Double Pepper Barbecue Chicken, Peri-Peri Chicken, Chicken Tikka & Grilled Chicken Rashers', 23, '2023-03-21 23:58:16', 'available'),
(82, 'INDI CHICKEN TIKKA', 'img/pizza-82.jpg\r\n', 319, 'The wholesome flavour of tandoori masala with Chicken tikka I onion I red paprika I mint mayo', 23, '2023-03-22 00:00:29', 'available'),
(83, 'CHICKEN FIESTA', 'img/pizza-83.jpg', 199, 'Grilled Chicken Rashers I Peri-Peri Chicken I Onion I Capsicum\r\n', 23, '2023-03-22 00:03:09', 'available'),
(85, 'CHEESY', 'img/pizza-85.jpg', 99, 'Orange Cheddar Cheese I Mozzarella', 22, '2023-03-22 12:34:14', 'available'),
(86, 'VEG LOADED', 'img/pizza-86.jpg', 149, 'Tomato | Grilled Mushroom |Jalapeno |Golden Corn | Beans in a fresh pan crust', 22, '2023-03-22 12:35:26', 'available'),
(87, 'CHEESE N TOMATO', 'img/pizza-87.jpg', 149, ' A delectable combination of cheese and juicy tomato', 22, '2023-03-22 12:36:14', 'available'),
(88, 'GOLDEN CORN', 'img/pizza-88.jpg', 139, 'Golden Corn', 22, '2023-03-22 12:37:07', 'available'),
(89, 'TOMATO', 'img/pizza-89.jpg', 99, 'Juicy tomato in a flavourful combination with cheese I tangy sauce\r\n', 22, '2023-03-22 12:38:57', 'available'),
(90, 'Garlic Breadsticks', 'img/pizza-90.jpg', 99, 'The endearing tang of garlic in breadstics baked to perfection.', 22, '2023-03-22 12:45:50', 'available'),
(91, 'Cheesy Garlic Bread', 'img/pizza-91.jpg', 149, ' Freshly Baked Garlic Bread stuffed with mozzarella cheese, sweet corns & tangy and spicy jalapeños', 22, '2023-03-22 12:46:47', 'available'),
(92, 'Stuffed Garlic Bread', 'img/pizza-92.jpg', 109, 'The endearing tang of garlic in breadstics baked to perfection.', 22, '2023-03-22 12:48:13', 'available'),
(93, 'Chocolate Garlic Bread', 'img/pizza-93.jpg', 159, 'tossed with extra virgin olive oil, exotic herbs & a generous helping of new flavoured sauce.', 22, '2023-03-22 12:51:01', 'available'),
(94, 'Cheese Jalapeno Bread', 'img/pizza-94.jpg', 159, 'A soft creamy cheese dip spiced with jalapeno.', 22, '2023-03-22 12:52:32', 'available'),
(95, 'COCA COLA CAN', 'img/pizza-95.jpg', 129, 'Coca cola tin..', 26, '2023-03-22 12:58:18', 'available'),
(96, 'PEPSI', 'img/pizza-96.jpg', 29, 'Colddrinks its pepsi..', 26, '2023-03-22 13:00:02', 'available'),
(97, 'COMBO DRINKS', 'img/pizza-97.jpg', 145, 'Combo Speacial offer..', 26, '2023-03-22 13:01:44', 'available'),
(98, 'COFFE', 'img/pizza-98.jpg', 99, 'Chocolaty hot coffe', 26, '2023-03-22 13:02:39', 'available'),
(99, 'CHOCO THIKSHAK', 'img/pizza-99.jpg', 89, 'Cold choco thiksahak...250 ml', 26, '2023-03-22 13:04:01', 'available'),
(100, 'LEMON DRINK', 'img/pizza-100.jpg', 99, 'Lemon water drink', 26, '2023-03-22 13:05:10', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `userId`, `itemId`, `created_at`) VALUES
(2, 6, 78, '2025-03-22 13:54:47'),
(4, 6, 70, '2025-03-30 05:14:43'),
(6, 6, 96, '2025-04-01 03:57:02'),
(8, 6, 72, '2025-04-01 07:00:31'),
(9, 16, 79, '2025-04-10 12:15:21'),
(10, 16, 93, '2025-04-10 12:15:31'),
(11, 16, 88, '2025-04-10 12:15:35'),
(12, 16, 78, '2025-04-11 06:02:08');

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(21) NOT NULL,
  `orderId` int(21) NOT NULL,
  `itemId` int(21) NOT NULL,
  `itemQuantity` int(100) NOT NULL,
  `size` varchar(255) NOT NULL DEFAULT 'M',
  `status` enum('available','out_of_stock') NOT NULL DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderitems`
--

INSERT INTO `orderitems` (`id`, `orderId`, `itemId`, `itemQuantity`, `size`, `status`) VALUES
(15, 15, 80, 1, 'S', 'available'),
(16, 16, 97, 1, 'L', 'available'),
(17, 17, 86, 1, 'M', 'available'),
(18, 18, 79, 1, 'S', 'available'),
(19, 19, 96, 1, 'S', 'available'),
(20, 20, 97, 1, 'S', 'available'),
(21, 21, 99, 1, 'M', 'available'),
(22, 22, 86, 1, 'L', 'available'),
(23, 23, 97, 1, 'S', 'available'),
(24, 24, 77, 1, 'L', 'available'),
(25, 25, 69, 1, 'S', 'available'),
(26, 25, 92, 1, 'M', 'available'),
(27, 25, 79, 1, 'L', 'available'),
(28, 26, 79, 1, 'S', 'available'),
(29, 27, 97, 3, 'S', 'available'),
(30, 27, 96, 1, 'L', 'available'),
(32, 28, 70, 1, 'S', 'available'),
(33, 29, 80, 1, 'M', 'available'),
(34, 30, 73, 7, 'M', 'available'),
(35, 31, 80, 1, 'L', 'available'),
(36, 32, 79, 1, 'L', 'available'),
(37, 33, 97, 1, 'M', 'available'),
(38, 34, 83, 1, 'M', 'available'),
(39, 35, 97, 1, 'M', 'available'),
(40, 36, 96, 1, 'L', 'available'),
(41, 37, 79, 1, 'S', 'available'),
(42, 38, 97, 1, 'M', 'available'),
(43, 39, 71, 1, 'L', 'available'),
(44, 40, 100, 1, 'L', 'available'),
(45, 41, 97, 1, 'L', 'available'),
(46, 42, 79, 1, 'S', 'available'),
(47, 43, 79, 1, 'M', 'available'),
(48, 44, 78, 7, 'S', 'available'),
(49, 44, 79, 1, 'S', 'available'),
(51, 45, 69, 1, 'S', 'available'),
(52, 46, 96, 1, 'M', 'available'),
(53, 46, 90, 1, 'L', 'available'),
(54, 47, 79, 4, 'S', 'available'),
(55, 47, 80, 1, 'S', 'available'),
(57, 48, 97, 5, 'S', 'available'),
(58, 48, 96, 1, 'S', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderId` int(11) NOT NULL,
  `userId` int(21) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipCode` int(21) NOT NULL,
  `phoneNo` bigint(21) NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_id` varchar(100) DEFAULT NULL,
  `paymentMode` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=cod,1=online',
  `orderStatus` enum('0','1','2','3','4','5','6') NOT NULL DEFAULT '0',
  `size` enum('S','M','L') NOT NULL DEFAULT 'M',
  `createdAt` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
  `delivery_boy_id` int(11) DEFAULT NULL,
  `deliveryTime` int(11) DEFAULT NULL COMMENT 'Delivery time in minutes',
  `finalDeliveryTime` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderId`, `userId`, `address`, `zipCode`, `phoneNo`, `amount`, `payment_id`, `paymentMode`, `orderStatus`, `size`, `createdAt`, `status`, `delivery_boy_id`, `deliveryTime`, `finalDeliveryTime`) VALUES
(34, 6, 'katargam', 395006, 9879719578, 437.00, 'pay_QDp1oLGWqNWrah', '1', '6', 'M', '2025-04-01 19:42:50', 'cancelled', 3, NULL, NULL),
(36, 6, '30, dangugev society, behind anath aashram', 563456, 9879719578, 111.00, 'pay_QFHQvWiTedAFmD', '1', '4', 'M', '2025-04-05 12:08:05', 'completed', 5, 40, 40),
(38, 6, 'katargam, surat', 395006, 9879719578, 324.00, NULL, '0', '4', 'M', '2025-04-07 11:24:05', 'completed', 5, 40, 40),
(40, 6, '30, dangugev society, behind anath aashram, katargam road, surat', 395006, 9879719578, 331.00, NULL, '0', '4', 'M', '2025-04-09 16:00:05', 'completed', 5, 60, 30),
(41, 16, '30, dangugev society, behind anath aashram', 395006, 9879719578, 476.00, 'pay_QHLXAwmtZsRQRc', '1', '4', 'M', '2025-04-10 17:27:44', 'completed', 5, 50, 40),
(42, 16, 'Varachha', 395006, 9879719578, 281.00, 'pay_QHb8P5brhMOtfH', '1', '1', 'M', '2025-04-11 08:42:06', 'pending', NULL, NULL, NULL),
(43, 16, 'ck pithawalla', 395006, 9512128080, 542.00, 'pay_QHbBcOWgR1YwMF', '1', '1', 'M', '2025-04-11 08:44:14', 'pending', 5, 25, NULL),
(44, 16, '30, dangugev society, behind anath aashram', 395006, 9879719578, 1744.00, 'pay_QHe23YAOZ9ZUzX', '1', '6', 'M', '2025-04-11 11:33:23', 'cancelled', NULL, NULL, NULL),
(45, 16, 'katargam, katargam road, surat', 563456, 9879719578, 123.00, NULL, '0', '4', 'M', '2025-04-11 11:36:19', 'completed', 5, 30, NULL),
(46, 6, 'hbhbhbhb', 246673, 9879719578, 392.00, 'pay_R4LSOSnGNPNEZZ', '1', '1', 'M', '2025-08-12 13:13:27', 'pending', 5, NULL, NULL),
(47, 6, '181, Parvat Gam Road', 394210, 9879719578, 1327.00, 'pay_RidToBjh7wlWKA', '1', '1', 'M', '2025-11-22 08:52:02', 'pending', 5, NULL, NULL),
(48, 6, '181, Parvat Gam Road', 394210, 9879719578, 811.00, 'pay_RieClpUEaa2Tiu', '1', '1', 'M', '2025-11-22 09:33:30', 'pending', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `reviewId` int(11) NOT NULL,
  `userId` int(21) NOT NULL,
  `orderId` int(21) NOT NULL,
  `rating` int(1) NOT NULL CHECK (`rating` between 1 and 5),
  `complain` text DEFAULT NULL COMMENT 'User complaint or feedback',
  `reviewDate` datetime NOT NULL DEFAULT current_timestamp(),
  `delivery_boy_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`reviewId`, `userId`, `orderId`, `rating`, `complain`, `reviewDate`, `delivery_boy_id`) VALUES
(5, 6, 17, 4, 'Nice Service and kind nature...', '2025-03-25 20:38:22', NULL),
(6, 6, 32, 5, 'Excellent service, very fast delivery!', '2025-04-01 21:45:48', NULL),
(7, 7, 33, 4, 'Good service but could be quicker.', '2025-04-01 21:45:48', 5),
(8, 8, 34, 3, 'Average experience, late delivery.', '2025-04-01 21:45:48', NULL),
(9, 9, 33, 2, 'Poor packaging, item was damaged.', '2025-04-01 21:45:48', 5),
(10, 10, 32, 1, 'Very bad experience, not satisfied.', '2025-04-01 21:45:48', NULL),
(12, 6, 36, 4, 'nice services..........kind nature...', '2025-04-07 11:35:03', 5),
(13, 6, 33, 3, 'do it betterrr', '2025-04-07 11:42:06', NULL),
(14, 6, 40, 4, 'nice....', '2025-04-09 16:10:10', 5),
(15, 16, 41, 4, 'nice nature good serving....', '2025-04-10 17:32:19', 5);

-- --------------------------------------------------------

--
-- Table structure for table `sitedetail`
--

CREATE TABLE `sitedetail` (
  `tempId` int(11) NOT NULL,
  `systemName` varchar(21) NOT NULL,
  `email` varchar(35) NOT NULL,
  `contact1` bigint(21) NOT NULL,
  `contact2` bigint(21) DEFAULT NULL COMMENT 'Optional',
  `address` text NOT NULL,
  `dateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sitedetail`
--

INSERT INTO `sitedetail` (`tempId`, `systemName`, `email`, `contact1`, `contact2`, `address`, `dateTime`) VALUES
(1, 'Pizza World', 'poojazanzmera31@gmail.com', 9879719578, 9512128080, 'C.K. Pithawalla <br>College of Commerce Management <br>and Computer Application<br> Surat', '2021-03-23 19:56:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(21) NOT NULL,
  `username` varchar(21) NOT NULL,
  `firstName` varchar(21) NOT NULL,
  `lastName` varchar(21) NOT NULL,
  `profilePic` varchar(255) DEFAULT NULL,
  `email` varchar(35) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `joinDate` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','blocked') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstName`, `lastName`, `profilePic`, `email`, `phone`, `password`, `joinDate`, `status`) VALUES
(6, 'pooja', 'Pallavi', 'Zanzmera', 'image/pooja.jpg', 'poojazanzmera31@gmail.com', 9879719578, '$2y$10$6ircp9JRqQqDHrwp/tBDoOztBNAmNtVzIDYUKb038sdUT93GvkL8a', '2025-03-22 19:23:35', 'active'),
(12, 'vardhit', 'Vardhit', 'Vamja', 'image/vardhit.jpg', 'vardhit21@gmail.com', 9791220563, '$2y$10$oYaygfVyyAJYHtFDZrVI2OVwDKu1DILZsFfCBuX5cQfTOR2oTehMi', '2025-03-26 18:35:29', 'active'),
(16, 'Divyraj', 'Divyraj', 'Gohil', '', 'divyrajsinh@gmail.com', 9512128080, '$2y$10$VaGXK6x92obKWsWV3Ydb.O7fLzapZWM8Ljoh/jKDsQRx0WppoY1Oq', '2025-04-10 17:26:40', 'active'),
(20, 'Prince', 'Prince', 'Patel', NULL, 'price@gmail.com', 9087689364, '$2y$10$sWrWGgWAbeoYiLv.RlYsaOoFrzK1j.1B9OJnRkeHKEJZvBTKwOBOi', '2025-11-21 14:25:39', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `viewcart`
--

CREATE TABLE `viewcart` (
  `cartItemId` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `itemQuantity` int(100) NOT NULL,
  `userId` int(11) NOT NULL,
  `addedDate` datetime NOT NULL DEFAULT current_timestamp(),
  `size` varchar(250) NOT NULL DEFAULT 'S M L'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categorieId`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contactId`),
  ADD KEY `userId` (`userId`),
  ADD KEY `orderId` (`orderId`);

--
-- Indexes for table `contactreply`
--
ALTER TABLE `contactreply`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contactId` (`contactId`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `delivery_boys`
--
ALTER TABLE `delivery_boys`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`itemId`),
  ADD KEY `pizzaCategorieId` (`itemCategorieId`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`),
  ADD KEY `pizzaId` (`itemId`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderId` (`orderId`),
  ADD KEY `pizzaId` (`itemId`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderId`),
  ADD KEY `userId` (`userId`),
  ADD KEY `delivery_boy_id` (`delivery_boy_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`reviewId`),
  ADD KEY `userId` (`userId`),
  ADD KEY `orderId` (`orderId`),
  ADD KEY `reviews_ibfk_3` (`delivery_boy_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `viewcart`
--
ALTER TABLE `viewcart`
  ADD PRIMARY KEY (`cartItemId`),
  ADD KEY `pizzaId` (`itemId`),
  ADD KEY `userId` (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `categorieId` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contactId` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `contactreply`
--
ALTER TABLE `contactreply`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `delivery_boys`
--
ALTER TABLE `delivery_boys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `itemId` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `reviewId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `viewcart`
--
ALTER TABLE `viewcart`
  MODIFY `cartItemId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contactreply`
--
ALTER TABLE `contactreply`
  ADD CONSTRAINT `contactreply_ibfk_1` FOREIGN KEY (`contactId`) REFERENCES `contact` (`contactId`) ON DELETE CASCADE,
  ADD CONSTRAINT `contactreply_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`delivery_boy_id`) REFERENCES `delivery_boys` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
