<?php
include '_dbconnect.php'; // Database connection file

// Fetch all reviews along with the delivery boy's name
$sql = "
    SELECT r.*, d.first_name, d.last_name 
    FROM reviews r
    LEFT JOIN delivery_boys d ON r.delivery_boy_id = d.id 
    ORDER BY r.reviewDate DESC"; // Newest reviews first
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviews & Complaints</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script> <!-- Font Awesome for Icons -->
</head>
<body>

<?php if (isset($_GET['msg'])): ?>
    <div class="alert <?php echo ($_GET['msg'] == 'deleted') ? 'alert-success' : 'alert-danger'; ?> text-center">
        <?php echo ($_GET['msg'] == 'deleted') ? 'Review deleted successfully!' : 'Error deleting review!'; ?>
    </div>
<?php endif; ?>

<div class="container-fluid" id="empty" style="margin-top: 20px; padding-top: 20px;">    
    <div class="row">
        <div class="card col-lg-12">
            <div class="card-body">
                <h2 class="text-center mb-4">User  Reviews & Complaints</h2>

                <table class="table table-striped table-bordered text-center">
                    <thead style="background-color: rgb(111 202 203);">
                        <tr>
                            <th>Review ID</th>
                            <th>User ID</th>
                            <th>Order ID</th>
                            <th>Rating</th>
                            <th>Complaint</th>
                            <th>Delivery Boy Name</th> 
                            <th>Review Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['reviewId']); ?></td>
                                    <td><?php echo htmlspecialchars($row['userId']); ?></td>
                                    <td><?php echo htmlspecialchars($row['orderId']); ?></td>
                                    <td><?php echo htmlspecialchars($row['rating']) . "/5"; ?></td> <!-- Rating as number -->
                                    <td><?php echo !empty($row['complain']) ? htmlspecialchars($row['complain']) : '<span class="text-muted">No Complaint</span>'; ?></td>
                                    <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['reviewDate']); ?></td>
                                    <td>
                                        <form action="partials/delete_review.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this review?');">
                                            <input type="hidden" name="reviewId" value="<?php echo $row['reviewId']; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8">No reviews or complaints found</td> <!-- Updated colspan -->
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>

</body>
</html>
<?php $conn->close(); ?>