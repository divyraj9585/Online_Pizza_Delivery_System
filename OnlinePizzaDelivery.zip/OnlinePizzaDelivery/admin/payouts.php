<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include 'partials/_dbconnect.php'; // Ensure the database connection is included

$sql = "SELECT o.orderId, o.amount, o.createdAt AS orderDate, 
               COALESCE(CONCAT(d.first_name, ' ', d.last_name), 'N/A') AS delivery_boy, 
               (o.amount * 0.1) AS payout 
        FROM orders o
        LEFT JOIN delivery_boys d ON o.delivery_boy_id = d.id
        WHERE o.orderStatus = '4' 
        ORDER BY o.createdAt DESC";
$result = $conn->query($sql);

$totalPayoutsSql = "SELECT COALESCE(CONCAT(d.first_name, ' ', d.last_name), 'N/A') AS delivery_boy, 
                            SUM(o.amount * 0.1) AS total_payout 
                     FROM orders o
                     LEFT JOIN delivery_boys d ON o.delivery_boy_id = d.id
                     WHERE o.orderStatus = '4' 
                     GROUP BY d.id";
$totalPayoutsResult = $conn->query($totalPayoutsSql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Payouts</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js"></script>
    <script>
        function printPage() {
            window.print();
        }
    </script>
</head>
<body>

<div class="container-fluid" style="margin-top: 20px; padding-top: 20px;">    
    <div class="row">
        <div class="card col-lg-12">
            <div class="card-body">
                <h2 class="text-center mb-4">Total Payouts Per Order</h2>

                <table class="table table-striped table-bordered text-center">
                    <thead style="background-color: rgb(111 202 203);">
                        <tr>
                            <th>Order ID</th>
                            <th>Amount (₹)</th>
                            <th>Delivery Date</th>
                            <th>Payout (₹)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['orderId']); ?></td>
                                    <td>₹<?= number_format($row['amount'], 2); ?></td>
                                    <td><?= date("d-m-Y H:i:s", strtotime($row['orderDate'])); ?></td>
                                    <td>₹<?= number_format($row['payout'], 2); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5">No payouts available.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="container" style="margin-top: 20px; margin-bottom: 20px; max-width: 500px;">    
    <div class="row">
        <div class="card col-lg-12">
            <div class="card-body">
                <h2 class="text-center mb-4" style="font-size: 1.5rem;">Total Payouts Per Delivery Boy</h2>

                <table class="table table-striped table-bordered text-center">
                    <thead style="background-color: rgb(111 202 203);">
                        <tr>
                            <th>Delivery Boy</th>
                            <th>Total Payout (₹)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($totalPayoutsResult->num_rows > 0): ?>
                            <?php while ($row = $totalPayoutsResult->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['delivery_boy']); ?></td>
                                    <td>₹<?= number_format($row['total_payout'], 2); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="2">No payouts available.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="text-center mt-3">
                    <button class="btn btn-primary" onclick="printPage()">Print</button>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
<?php $conn->close(); ?>