<?php
include '_dbconnect.php'; // Database connection

// Fetch pending delivery requests
$pendingQuery = "SELECT id, delivery_boy_name, first_name, last_name, email, phone, vehicle_type FROM delivery_boys WHERE status='pending'";
$pendingResult = mysqli_query($conn, $pendingQuery);

// Fetch approved delivery boys
$approvedQuery = "SELECT id, delivery_boy_name, first_name, last_name, email, phone, vehicle_type FROM delivery_boys WHERE status='approved'";
$approvedResult = mysqli_query($conn, $approvedQuery);

// Fetch rejected delivery boys
$rejectedQuery = "SELECT id, delivery_boy_name, first_name, last_name, email, phone, vehicle_type FROM delivery_boys WHERE status='rejected'";
$rejectedResult = mysqli_query($conn, $rejectedQuery);

$alertMessage = "";
if (isset($_GET['msg'])) {
    $msg = htmlspecialchars($_GET['msg']); // Prevent XSS attacks
    if ($msg == "approved") {
        $alertMessage = "Delivery request approved successfully!";
    } elseif ($msg == "rejected") {
        $alertMessage = "Delivery request rejected!";
    } elseif ($msg == "removed") {
        $alertMessage = "Delivery boy removed successfully!";
    } elseif ($msg == "error") {
        $alertMessage = "Error removing delivery boy!";
    }
}
?>

<!-- JavaScript for Alert Message -->
<script>
    document.addEventListener("DOMContentLoaded", function () {
        let message = "<?php echo $alertMessage; ?>";
        if (message) {
            alert(message);
            window.location.href = "index.php?page=deliveryRequests";
        }
    });
</script>

<div class="container-fluid" id="empty" style="margin-top: 20px; padding-top: 20px;">

    <div class="row">
        <div class="card col-lg-12">
            <div class="card-body">
                <h3 class="text-center">Pending Delivery Requests</h3>
                <table class="table table-striped table-bordered col-md-12 text-center">
                    <thead style="background-color: rgb(111 202 203);">
                        <tr>
                            <th>ID</th>
                            <th>Delivery Boy Name</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Vehicle</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($pendingResult)) {
                                $count++;
                                echo '<tr>
                                        <td>' . htmlspecialchars($row['id']) . '</td>
                                        <td>' . htmlspecialchars($row['delivery_boy_name']) . '</td>
                                        <td>' . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . '</td>
                                        <td>' . htmlspecialchars($row['email']) . '</td>
                                        <td>' . htmlspecialchars($row['phone']) . '</td>
                                        <td>' . htmlspecialchars($row['vehicle_type'] ? $row['vehicle_type'] : 'N/A') . '</td>
                                        <td>
                                            <a href="partials/_manageDeliveryBoy.php?id=' . urlencode($row['id']) . '&action=approve" class="btn btn-success btn-sm">Accept</a>
                                            <a href="partials/_manageDeliveryBoy.php?id=' . urlencode($row['id']) . '&action=reject" class="btn btn-danger btn-sm">Reject</a>
                                        </td>
                                    </tr>';
                            }
                            if ($count == 0) {
                                echo '<tr><td colspan="7" class="text-center"><div class="alert alert-info">No pending delivery requests!</div></td></tr>';
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Approved Delivery Boys Section -->
    <div class="row mt-5">
        <div class="card col-lg-12">
            <div class="card-body">
                <h3 class="text-center">Approved Delivery Boys</h3>
                <table class="table table-striped table-bordered col-md-12 text-center">
                    <thead style="background-color: rgb(111 202 203);">
                        <tr>
                            <th>ID</th>
                            <th>Delivery Boy Name</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Vehicle</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($approvedResult)) {
                                $count++;
                                echo '<tr>
                                        <td>' . htmlspecialchars($row['id']) . '</td>
                                        <td>' . htmlspecialchars($row['delivery_boy_name']) . '</td>
                                        <td>' . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . '</td>
                                        <td>' . htmlspecialchars($row['email']) . '</td>
                                        <td>' . htmlspecialchars($row['phone']) . '</td>
                                        <td>' . htmlspecialchars($row['vehicle_type'] ? $row['vehicle_type'] : 'N/A') . '</td>
                                        <td>
                                            <a href="partials/_manageDeliveryBoy.php?id=' . urlencode($row['id']) . '&action=remove" class="btn btn-warning btn-sm">Remove</a>
                                        </td>
                                    </tr>';
                            }
                            if ($count == 0) {
                                echo '<tr><td colspan="7" class="text-center"><div class="alert alert-info">No approved delivery boys yet!</div></td></tr>';
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Rejected Delivery Boys Section -->
    <div class="row mt-5">
        <div class="card col-lg-12">
            <div class="card-body">
                <h3 class="text-center">Rejected Delivery Boys</h3>
                <table class="table table-striped table-bordered col-md-12 text-center">
                    <thead style="background-color: rgb(111 202 203);">
                        <tr>
                            <th>ID</th>
                            <th>Delivery Boy Name</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Vehicle</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $count = 0;
                            while ($row = mysqli_fetch_assoc($rejectedResult)) {
                                $count++;
                                echo '<tr>
                                        <td>' . htmlspecialchars($row['id']) . '</td>
                                        <td>' . htmlspecialchars($row['delivery_boy_name']) . '</td>
                                        <td>' . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . '</td>
                                        <td>' . htmlspecialchars($row['email']) . '</td>
                                        <td>' . htmlspecialchars($row['phone']) . '</td>
                                        <td>' . htmlspecialchars($row['vehicle_type'] ? $row['vehicle_type'] : 'N/A') . '</td>
                                    </tr>';
                            }
                            if ($count == 0) {
                                echo '<tr><td colspan="6" class="text-center"><div class="alert alert-info">No rejected delivery boys yet!</div></td></tr>';
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<br><br>