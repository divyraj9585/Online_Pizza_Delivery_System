
<?php
define('RAZORPAY_KEY_ID', 'rzp_test_cXtUFZJ1mIbI9S');
?>
